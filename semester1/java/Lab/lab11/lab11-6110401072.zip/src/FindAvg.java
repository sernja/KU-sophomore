import java.util.ArrayList;

public class FindAvg {
    private double avg;

    public FindAvg(ArrayList<Student> students){
        int i = 0;
        double countScore = 0;
        for (Student student : students) {
            i += 1;
            countScore += student.getScore();
        }
        this.avg = countScore/i;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public double getAvg() {
        return avg;
    }
}
